# HINA PLAYZ — Phase 1 + UI Foundation (1.2)

Native Android offline music player built with Kotlin, Jetpack Compose, Material 3 and AndroidX Media3.

## Implemented in this source update
- Persistent local favourites.
- MediaStore scanning on the IO dispatcher, with loading state and safer metadata/error handling.
- Playback service audio-focus configuration and audio-noisy handling.
- Added persistent appearance setting: Follow System, Light Mode and Dark Mode.
- Added light/dark Material 3 palettes based on the supplied visual direction, including matching system status/navigation bars.
- Added an appearance/settings entry in the app header.
- App version 1.2 (versionCode 3).

## Build
Use JDK 17, Android SDK 35 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Not yet implemented
The supplied PRD is larger than one safe phase. Search/Home/History navigation, album and artist detail pages, artwork extraction, playlists, queue UI, real Equalizer, sleep timer, waveform and expanded animations remain future phases. Do not treat this version as the completed PRD.

## Device testing still required
Verify permission flows, library scan, favourites after restart, all three theme modes, background playback, notification/lock-screen controls, audio interruptions and headset disconnection on a physical Android device. A successful Gradle build alone does not prove these behaviors.


## Version 1.3 — Phase 3 UI foundation

- Added four primary destinations: Home, Search, Library, and History.
- Added local song search across title, artist, and album metadata.
- Added All Songs / Favorites filtering in Library.
- Added a persistent, most-recent-first playback history (up to 100 track IDs).
- Added a Home landing section and retained the persistent mini-player.
- Restyled the bottom navigation and mini-player surfaces with subtle translucent styling.

Build with the existing GitHub Actions workflow (`gradle assembleDebug`). The build has not been executed in this editing environment; run the workflow and test on-device before treating this version as release-ready.
