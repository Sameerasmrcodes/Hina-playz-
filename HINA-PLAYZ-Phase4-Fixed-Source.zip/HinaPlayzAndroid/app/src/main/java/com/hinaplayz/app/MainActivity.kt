package com.hinaplayz.app

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.border
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.guava.await

private val Ink: Color @Composable get() = MaterialTheme.colorScheme.background
private val Panel: Color @Composable get() = MaterialTheme.colorScheme.surface
private val Panel2: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant
private val SoftWhite: Color @Composable get() = MaterialTheme.colorScheme.onBackground
private val Muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
private val Line: Color @Composable get() = MaterialTheme.colorScheme.outlineVariant

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    var playerState by mutableStateOf<MediaController?>(null)
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { playerState = controllerFuture?.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))

        window.statusBarColor = android.graphics.Color.rgb(8, 8, 8)
        window.navigationBarColor = android.graphics.Color.rgb(8, 8, 8)
        setContent { HinaPlayzApp(playerState) }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun HinaPlayzApp(controller: MediaController?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as ComponentActivity
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val preferences = remember(context) {
        context.getSharedPreferences("hina_playz_preferences", android.content.Context.MODE_PRIVATE)
    }
    var favorites by remember {
        mutableStateOf(
            preferences.getStringSet("favorite_track_ids", emptySet())
                .orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
        )
    }
    var isLoading by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }
    var libraryFilter by remember { mutableStateOf("all") }
    var historyIds by remember {
        mutableStateOf(preferences.getString("play_history_ids", "").orEmpty().split(",").mapNotNull { it.toLongOrNull() }.distinct())
    }
    var showSettings by remember { mutableStateOf(false) }
    var themeMode by remember { mutableStateOf(preferences.getString("theme_mode", "system") ?: "system") }
    val systemDark = isSystemInDarkTheme()
    val darkTheme = when (themeMode) { "dark" -> true; "light" -> false; else -> systemDark }
    var fullPlayer by remember { mutableStateOf(false) }
    var selectedTrackId by remember { mutableStateOf<Long?>(null) }
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> permissionGranted = granted }

    val scope = rememberCoroutineScope()
    fun loadTracks() {
        if (!permissionGranted) return
        scope.launch {
            isLoading = true
            val found = withContext(Dispatchers.IO) {
                val result = mutableListOf<Track>()
                val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val projection = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION
                )
                try {
                    context.contentResolver.query(
                        collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
                        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                    )?.use { cursor ->
                        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                        val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                        val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                        val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                        val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                        while (cursor.moveToNext()) {
                            val id = cursor.getLong(idCol)
                            val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                                ?: "Unknown track"
                            val artist = cursor.getString(artistCol)
                                ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                                ?: "Unknown artist"
                            val album = cursor.getString(albumCol)
                                ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                                ?: "Unknown album"
                            result += Track(
                                id = id,
                                title = title,
                                artist = artist,
                                album = album,
                                duration = cursor.getLong(durationCol).coerceAtLeast(0L),
                                uri = ContentUris.withAppendedId(collection, id)
                            )
                        }
                    }
                } catch (_: SecurityException) {
                    // Permission may have been revoked while the library was scanning.
                } catch (_: IllegalArgumentException) {
                    // Some device MediaStore providers reject optional query details.
                }
                result
            }
            tracks = found
            isLoading = false
        }
    }

    LaunchedEffect(favorites) {
        preferences.edit()
            .putStringSet("favorite_track_ids", favorites.map { it.toString() }.toSet())
            .apply()
    }


    LaunchedEffect(permissionGranted) {
        if (permissionGranted) loadTracks()
    }

    val currentUri = controller?.currentMediaItem?.localConfiguration?.uri
    val currentTrack = tracks.firstOrNull { it.id == selectedTrackId }
        ?: tracks.firstOrNull { it.uri == currentUri }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var total by remember { mutableLongStateOf(0L) }
    LaunchedEffect(controller, tracks) {
        while (true) {
            if (controller != null) {
                playing = controller.isPlaying
                position = controller.currentPosition.coerceAtLeast(0L)
                total = controller.duration.takeIf { it > 0 } ?: (currentTrack?.duration ?: 0L)
                val activeUri = controller.currentMediaItem?.localConfiguration?.uri
                val activeId = tracks.firstOrNull { it.uri == activeUri }?.id
                if (activeId != null && selectedTrackId != activeId) selectedTrackId = activeId
            }
            delay(450)
        }
    }

    LaunchedEffect(currentTrack?.id) {
        currentTrack?.let { track ->
            historyIds = (listOf(track.id) + historyIds.filterNot { it == track.id }).take(100)
            preferences.edit().putString("play_history_ids", historyIds.joinToString(",")).apply()
        }
    }

    val searchedTracks = remember(tracks, query) {
        tracks.filter { query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }
    }
    val visibleTracks = remember(tracks, searchedTracks, selectedTab, libraryFilter, favorites, historyIds) {
        when (selectedTab) {
            0 -> tracks.take(8) // Home: recently added
            1 -> searchedTracks
            2 -> if (libraryFilter == "favorites") tracks.filter { it.id in favorites } else tracks
            else -> historyIds.mapNotNull { id -> tracks.firstOrNull { it.id == id } }
        }
    }

    val palette = if (darkTheme) darkColorScheme(
        primary = Color(0xFFF5F5F7), onPrimary = Color(0xFF151720),
        background = Color(0xFF151720), onBackground = Color(0xFFF7F7F9),
        surface = Color(0xFF20232E), onSurface = Color(0xFFF7F7F9),
        surfaceVariant = Color(0xFF292D39), onSurfaceVariant = Color(0xFF9296A3),
        outlineVariant = Color(0xFF3A3E49), secondary = Color(0xFF9296A3)
    ) else lightColorScheme(
        primary = Color(0xFF171923), onPrimary = Color.White,
        background = Color(0xFFF7F7F9), onBackground = Color(0xFF171923),
        surface = Color.White, onSurface = Color(0xFF171923),
        surfaceVariant = Color(0xFFECEEF2), onSurfaceVariant = Color(0xFF858995),
        outlineVariant = Color(0xFFE0E2E7), secondary = Color(0xFF858995)
    )
    MaterialTheme(colorScheme = palette) {
        val view = LocalView.current
        SideEffect {
            val window = (view.context as? ComponentActivity)?.window
            val bar = if (darkTheme) android.graphics.Color.rgb(21, 23, 32) else android.graphics.Color.rgb(247, 247, 249)
            window?.statusBarColor = bar
            window?.navigationBarColor = bar
            if (Build.VERSION.SDK_INT >= 26) {
                window?.decorView?.systemUiVisibility = if (darkTheme) 0 else
                    (android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
            }
        }
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                TopHeader(onSettings = { showSettings = true })
                if (showSettings) {
                    AlertDialog(
                        onDismissRequest = { showSettings = false },
                        title = { Text("Appearance") },
                        text = {
                            Column {
                                listOf("system" to "Follow system", "light" to "Light mode", "dark" to "Dark mode").forEach { (value, label) ->
                                    Row(Modifier.fillMaxWidth().clickable {
                                        themeMode = value
                                        preferences.edit().putString("theme_mode", value).apply()
                                    }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = themeMode == value, onClick = {
                                            themeMode = value
                                            preferences.edit().putString("theme_mode", value).apply()
                                        })
                                        Spacer(Modifier.width(8.dp))
                                        Text(label)
                                    }
                                }
                            }
                        },
                        confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
                    )
                }
                if (fullPlayer && currentTrack != null) {
                    FullPlayer(
                        track = currentTrack, controller = controller, playing = playing,
                        position = position, total = total,
                        onClose = { fullPlayer = false },
                        onFavorite = { favorites = if (currentTrack.id in favorites) favorites - currentTrack.id else favorites + currentTrack.id },
                        isFavorite = currentTrack.id in favorites
                    )
                } else {
                    when (selectedTab) {
                        0 -> {
                            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 12.dp)) {
                                Text("GOOD MUSIC, GOOD MOOD", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                Text("Your sound space.", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Your music", color = SoftWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Text("${tracks.size} songs in your collection", color = Muted, fontSize = 12.sp)
                            }
                        }
                        1 -> {
                            OutlinedTextField(
                                value = query, onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                                placeholder = { Text("Songs, artists, albums", color = Muted) },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null, tint = Muted) } },
                                singleLine = true, shape = RoundedCornerShape(18.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SoftWhite, unfocusedBorderColor = Line, focusedTextColor = SoftWhite, unfocusedTextColor = SoftWhite, cursorColor = SoftWhite)
                            )
                        }
                        2 -> {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                TabPill("All songs", libraryFilter == "all") { libraryFilter = "all" }
                                TabPill("Favorites", libraryFilter == "favorites") { libraryFilter = "favorites" }
                            }
                        }
                        else -> {
                            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)) {
                                Text("YOUR LISTENING", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                Text("Recently played", color = SoftWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(when (selectedTab) { 0 -> "PICKED FOR YOU"; 1 -> "SEARCH RESULTS"; 2 -> "YOUR LIBRARY"; else -> "PLAYBACK HISTORY" }, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("${visibleTracks.size} tracks", color = SoftWhite, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        }
                        IconButton(onClick = { if (permissionGranted) loadTracks() else permissionLauncher.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE) }) {
                            Icon(Icons.Default.Refresh, "Refresh library", tint = Muted)
                        }
                    }
                    if (!permissionGranted) {
                        EmptyState(Icons.Default.LibraryMusic, "Your music, one place.", "Allow audio access to find songs stored on your phone.", "ALLOW ACCESS") {
                            permissionLauncher.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                    } else if (isLoading && tracks.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = SoftWhite) }
                    } else if (visibleTracks.isEmpty()) {
                        EmptyState(Icons.Default.MusicOff, when (selectedTab) { 1 -> "No matches found"; 2 -> if (libraryFilter == "favorites") "No favorites yet" else "Library is empty"; 3 -> "Nothing played yet"; else -> "No music found" }, "Your local music will appear here when available.", "REFRESH") { loadTracks() }
                    } else {
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            itemsIndexed(visibleTracks, key = { _, track -> track.id }) { index, track ->
                                TrackRow(track, index, currentTrack?.id == track.id, track.id in favorites, onClick = {
                                    val items = tracks.map { item -> MediaItem.Builder().setUri(item.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(item.title).setArtist(item.artist).setAlbumTitle(item.album).build()).build() }
                                    val startIndex = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
                                    selectedTrackId = track.id
                                    fullPlayer = true
                                    controller?.setMediaItems(items, startIndex, 0L)
                                    controller?.prepare()
                                    controller?.play()
                                }, onFavorite = { favorites = if (track.id in favorites) favorites - track.id else favorites + track.id })
                            }
                        }
                    }
                    AnimatedVisibility(visible = currentTrack != null) {
                        MiniPlayer(track = currentTrack, playing = playing, position = position, total = total, onOpen = { fullPlayer = true }, onPlayPause = { if (playing) controller?.pause() else controller?.play() }, onNext = { controller?.seekToNextMediaItem() })
                    }
                    BottomBar(selectedTab = selectedTab, onSelect = { selectedTab = it })
                }
            }
        }
    }
}

@Composable
private fun TopHeader(onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(SoftWhite),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.GraphicEq, null, tint = Ink, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("HINA PLAYZ", color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("LISTEN BEYOND", color = Muted, fontSize = 8.sp, letterSpacing = 2.4.sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings and appearance", tint = Muted)
        }
    }
}

@Composable
private fun TabPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape)
            .background(if (selected) SoftWhite else Panel)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(label, color = if (selected) Ink else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TrackRow(
    track: Track, index: Int, isCurrent: Boolean, isFavorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
            .background(if (isCurrent) Panel2 else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                .background(if (isCurrent) SoftWhite else Panel2),
            contentAlignment = Alignment.Center
        ) {
            if (isCurrent) Icon(Icons.Default.GraphicEq, null, tint = Ink)
            else Text("%02d".format(index + 1), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(track.title, color = if (isCurrent) SoftWhite else SoftWhite, fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(formatTime(track.duration), color = Muted, fontSize = 10.sp)
        IconButton(onClick = onFavorite, modifier = Modifier.size(38.dp)) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                null, tint = if (isFavorite) SoftWhite else Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun MiniPlayer(
    track: Track?, playing: Boolean, position: Long, total: Long,
    onOpen: () -> Unit, onPlayPause: () -> Unit, onNext: () -> Unit
) {
    if (track == null) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel.copy(alpha = 0.94f))
                .clickable(onClick = onOpen).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = SoftWhite)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(track.artist, color = Muted, fontSize = 10.sp, maxLines = 1)
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = SoftWhite)
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, null, tint = SoftWhite)
            }
        }
        LinearProgressIndicator(
            progress = { if (total > 0) (position.toFloat() / total).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(2.dp),
            color = SoftWhite, trackColor = Panel2
        )
    }
}

@Composable
private fun FullPlayer(
    track: Track, controller: MediaController?, playing: Boolean,
    position: Long, total: Long, onClose: () -> Unit,
    onFavorite: () -> Unit, isFavorite: Boolean
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = SoftWhite) }
            Spacer(Modifier.weight(1f))
            Text("NOW PLAYING", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite", tint = SoftWhite)
            }
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(
                    Color(0xFF41485A).copy(alpha = 0.88f),
                    Color(0xFF222633).copy(alpha = 0.96f),
                    Color(0xFF151720)
                )))
                .border(1.dp, SoftWhite.copy(alpha = 0.16f), RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.GraphicEq, null, tint = SoftWhite, modifier = Modifier.size(112.dp))
            Text("H", color = Color(0x22FFFFFF), fontSize = 210.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(35.dp))
        Text(track.title, color = SoftWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(7.dp))
        Text(track.artist, color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(30.dp))
        Slider(
            value = if (total > 0) (position.toFloat() / total).coerceIn(0f, 1f) else 0f,
            onValueChange = { controller?.seekTo((it * total).toLong()) },
            colors = SliderDefaults.colors(thumbColor = SoftWhite, activeTrackColor = SoftWhite, inactiveTrackColor = Panel2)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Muted, fontSize = 10.sp)
            Text(formatTime(total), color = Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { controller?.shuffleModeEnabled = !(controller?.shuffleModeEnabled ?: false) }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (controller?.shuffleModeEnabled == true) SoftWhite else Muted)
            }
            IconButton(onClick = { controller?.seekToPreviousMediaItem() }, modifier = Modifier.size(58.dp)) {
                Icon(Icons.Default.SkipPrevious, "Previous", tint = SoftWhite, modifier = Modifier.size(35.dp))
            }
            Box(
                Modifier.size(72.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color.White, Color(0xFFD9DCE5))))
                    .clickable {
                    if (playing) controller?.pause() else controller?.play()
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    if (playing) "Pause" else "Play", tint = Ink, modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = { controller?.seekToNextMediaItem() }, modifier = Modifier.size(58.dp)) {
                Icon(Icons.Default.SkipNext, "Next", tint = SoftWhite, modifier = Modifier.size(35.dp))
            }
            IconButton(onClick = {
                controller?.repeatMode = when (controller?.repeatMode) {
                    androidx.media3.common.Player.REPEAT_MODE_OFF -> androidx.media3.common.Player.REPEAT_MODE_ALL
                    androidx.media3.common.Player.REPEAT_MODE_ALL -> androidx.media3.common.Player.REPEAT_MODE_ONE
                    else -> androidx.media3.common.Player.REPEAT_MODE_OFF
                }
            }) {
                Icon(Icons.Default.Repeat, "Repeat", tint = if ((controller?.repeatMode ?: 0) != 0) SoftWhite else Muted)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("HINA PLAYZ  •  LISTEN BEYOND", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun BottomBar(selectedTab: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp)
            .clip(RoundedCornerShape(24.dp)).background(Panel.copy(alpha = 0.96f))
            .navigationBarsPadding().padding(vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavigationItem(Icons.Default.Home, "HOME", selectedTab == 0) { onSelect(0) }
        NavigationItem(Icons.Default.Search, "SEARCH", selectedTab == 1) { onSelect(1) }
        NavigationItem(Icons.Default.LibraryMusic, "LIBRARY", selectedTab == 2) { onSelect(2) }
        NavigationItem(Icons.Default.History, "HISTORY", selectedTab == 3) { onSelect(3) }
    }
}

@Composable
private fun NavigationItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 9.dp)
            .heightIn(min = 42.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = if (selected) SoftWhite else Muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (selected) SoftWhite else Muted, fontSize = 8.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String, message: String, action: String, onAction: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().fillMaxHeight().padding(horizontal = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(Panel), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = SoftWhite, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(22.dp))
        Text(title, color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(containerColor = SoftWhite, contentColor = Ink),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(action, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}
