# HINA PLAYZ — Android

A native Android music player built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features
- Scans audio files indexed by Android MediaStore
- Local library with search
- Favorites (session-only in this starter version)
- Playback queue, play/pause, previous/next, seek, shuffle and repeat
- MediaSessionService for notification / background media-session integration
- Black + white minimal premium interface

## Build an APK
This environment did not include the Android SDK or Gradle, so an APK could not be compiled here. Open this project in Android Studio on a computer with Android SDK installed:

1. Choose **Open** and select the `HinaPlayzAndroid` folder.
2. Let Gradle sync and install the requested SDK platform (API 35) if prompted.
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Press **Run** to install and test.
5. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 6.0 (API 23).

## Notes
- The app plays audio files that Android exposes through MediaStore. DRM-protected streaming services are not supported.
- Favorites are currently held in app memory and reset when the process is fully restarted.
- Background playback and lock-screen controls are provided through Media3 MediaSessionService; test notification permission on Android 13+.
