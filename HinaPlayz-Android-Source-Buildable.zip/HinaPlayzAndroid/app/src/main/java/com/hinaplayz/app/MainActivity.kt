package com.hinaplayz.app

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.guava.await

private val Ink = Color(0xFF080808)
private val Panel = Color(0xFF151515)
private val Panel2 = Color(0xFF202020)
private val SoftWhite = Color(0xFFF5F5F5)
private val Muted = Color(0xFF929292)
private val Line = Color(0xFF292929)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    var playerState by mutableStateOf<MediaController?>(null)
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { playerState = controllerFuture?.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))

        window.statusBarColor = android.graphics.Color.rgb(8, 8, 8)
        window.navigationBarColor = android.graphics.Color.rgb(8, 8, 8)
        setContent { HinaPlayzApp(playerState) }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun HinaPlayzApp(controller: MediaController?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as ComponentActivity
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var favorites by remember { mutableStateOf(setOf<Long>()) }
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }
    var fullPlayer by remember { mutableStateOf(false) }
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> permissionGranted = granted }

    fun loadTracks() {
        val found = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        context.contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                found += Track(
                    id = id,
                    title = cursor.getString(titleCol) ?: "Unknown track",
                    artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                    album = cursor.getString(albumCol) ?: "",
                    duration = cursor.getLong(durationCol),
                    uri = ContentUris.withAppendedId(collection, id)
                )
            }
        }
        tracks = found
    }

    LaunchedEffect(permissionGranted) {
        if (permissionGranted) loadTracks()
    }

    val currentUri = controller?.currentMediaItem?.localConfiguration?.uri
    val currentTrack = tracks.firstOrNull { it.uri == currentUri }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var total by remember { mutableLongStateOf(0L) }
    LaunchedEffect(controller) {
        while (true) {
            if (controller != null) {
                playing = controller.isPlaying
                position = controller.currentPosition.coerceAtLeast(0L)
                total = controller.duration.takeIf { it > 0 } ?: (currentTrack?.duration ?: 0L)
            }
            delay(450)
        }
    }

    val visibleTracks = remember(tracks, query, selectedTab, favorites) {
        tracks.filter {
            (selectedTab != 1 || it.id in favorites) &&
            (query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true))
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = SoftWhite,
            onPrimary = Ink, onBackground = SoftWhite, onSurface = SoftWhite,
            secondary = Muted
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                TopHeader()
                if (fullPlayer && currentTrack != null) {
                    FullPlayer(
                        track = currentTrack, controller = controller, playing = playing,
                        position = position, total = total,
                        onClose = { fullPlayer = false },
                        onFavorite = { favorites = if (currentTrack.id in favorites) favorites - currentTrack.id else favorites + currentTrack.id },
                        isFavorite = currentTrack.id in favorites
                    )
                } else {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TabPill("All songs", selectedTab == 0) { selectedTab = 0 }
                        TabPill("Favorites", selectedTab == 1) { selectedTab = 1 }
                    }
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                        placeholder = { Text("Search your music", color = Muted) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                        trailingIcon = {
                            if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, null, tint = Muted)
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF777777),
                            unfocusedBorderColor = Line,
                            focusedTextColor = SoftWhite,
                            unfocusedTextColor = SoftWhite,
                            cursorColor = SoftWhite
                        )
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(if (selectedTab == 1) "YOUR FAVORITES" else "YOUR LIBRARY",
                                color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("${visibleTracks.size} tracks", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                        }
                        IconButton(onClick = { if (permissionGranted) loadTracks() else permissionLauncher.launch(
                            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                            else Manifest.permission.READ_EXTERNAL_STORAGE
                        ) }) {
                            Icon(Icons.Default.Refresh, "Refresh library", tint = Muted)
                        }
                    }

                    if (!permissionGranted) {
                        EmptyState(
                            icon = Icons.Default.LibraryMusic,
                            title = "Your music, one place.",
                            message = "Allow audio access to find songs stored on your phone.",
                            action = "ALLOW ACCESS",
                            onAction = {
                                permissionLauncher.launch(
                                    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                                    else Manifest.permission.READ_EXTERNAL_STORAGE
                                )
                            }
                        )
                    } else if (visibleTracks.isEmpty()) {
                        EmptyState(
                            icon = if (selectedTab == 1) Icons.Default.FavoriteBorder else Icons.Default.MusicOff,
                            title = if (selectedTab == 1) "No favorites yet" else "No music found",
                            message = if (selectedTab == 1) "Tap the heart on a track to save it here." else "Add audio files to your device, then refresh your library.",
                            action = "REFRESH",
                            onAction = { loadTracks() }
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            itemsIndexed(visibleTracks, key = { _, track -> track.id }) { index, track ->
                                TrackRow(
                                    track = track,
                                    index = index,
                                    isCurrent = currentTrack?.id == track.id,
                                    isFavorite = track.id in favorites,
                                    onClick = {
                                        val items = tracks.map { trackItem ->
                                            MediaItem.Builder().setUri(trackItem.uri).setMediaMetadata(
                                                MediaMetadata.Builder().setTitle(trackItem.title)
                                                    .setArtist(trackItem.artist).setAlbumTitle(trackItem.album).build()
                                            ).build()
                                        }
                                        val startIndex = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
                                        controller?.setMediaItems(items, startIndex, 0L)
                                        controller?.prepare()
                                        controller?.play()
                                    },
                                    onFavorite = {
                                        favorites = if (track.id in favorites) favorites - track.id else favorites + track.id
                                    }
                                )
                            }
                        }
                    }
                    AnimatedVisibility(visible = currentTrack != null) {
                        MiniPlayer(
                            track = currentTrack,
                            playing = playing,
                            position = position,
                            total = total,
                            onOpen = { fullPlayer = true },
                            onPlayPause = { if (playing) controller?.pause() else controller?.play() },
                            onNext = { controller?.seekToNextMediaItem() }
                        )
                    }
                    BottomBar(selectedTab = selectedTab, onHome = { selectedTab = 0 }, onFavorites = { selectedTab = 1 })
                }
            }
        }
    }
}

@Composable
private fun TopHeader() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(SoftWhite),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.GraphicEq, null, tint = Ink, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("HINA PLAYZ", color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("LISTEN BEYOND", color = Muted, fontSize = 8.sp, letterSpacing = 2.4.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFBDBDBD)))
    }
}

@Composable
private fun TabPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape)
            .background(if (selected) SoftWhite else Panel)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(label, color = if (selected) Ink else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TrackRow(
    track: Track, index: Int, isCurrent: Boolean, isFavorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
            .background(if (isCurrent) Panel2 else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                .background(if (isCurrent) SoftWhite else Panel2),
            contentAlignment = Alignment.Center
        ) {
            if (isCurrent) Icon(Icons.Default.GraphicEq, null, tint = Ink)
            else Text("%02d".format(index + 1), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(track.title, color = if (isCurrent) SoftWhite else SoftWhite, fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(formatTime(track.duration), color = Muted, fontSize = 10.sp)
        IconButton(onClick = onFavorite, modifier = Modifier.size(38.dp)) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                null, tint = if (isFavorite) SoftWhite else Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun MiniPlayer(
    track: Track?, playing: Boolean, position: Long, total: Long,
    onOpen: () -> Unit, onPlayPause: () -> Unit, onNext: () -> Unit
) {
    if (track == null) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel)
                .clickable(onClick = onOpen).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = SoftWhite)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, color = SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(track.artist, color = Muted, fontSize = 10.sp, maxLines = 1)
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = SoftWhite)
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, null, tint = SoftWhite)
            }
        }
        LinearProgressIndicator(
            progress = { if (total > 0) (position.toFloat() / total).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(2.dp),
            color = SoftWhite, trackColor = Panel2
        )
    }
}

@Composable
private fun FullPlayer(
    track: Track, controller: MediaController?, playing: Boolean,
    position: Long, total: Long, onClose: () -> Unit,
    onFavorite: () -> Unit, isFavorite: Boolean
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = SoftWhite) }
            Spacer(Modifier.weight(1f))
            Text("NOW PLAYING", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite", tint = SoftWhite)
            }
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp))
                .background(Panel2),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.GraphicEq, null, tint = SoftWhite, modifier = Modifier.size(112.dp))
            Text("H", color = Color(0x22FFFFFF), fontSize = 210.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(35.dp))
        Text(track.title, color = SoftWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(7.dp))
        Text(track.artist, color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(30.dp))
        Slider(
            value = if (total > 0) (position.toFloat() / total).coerceIn(0f, 1f) else 0f,
            onValueChange = { controller?.seekTo((it * total).toLong()) },
            colors = SliderDefaults.colors(thumbColor = SoftWhite, activeTrackColor = SoftWhite, inactiveTrackColor = Panel2)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Muted, fontSize = 10.sp)
            Text(formatTime(total), color = Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { controller?.shuffleModeEnabled = !(controller?.shuffleModeEnabled ?: false) }) {
                Icon(Icons.Default.Shuffle, "Shuffle", tint = if (controller?.shuffleModeEnabled == true) SoftWhite else Muted)
            }
            IconButton(onClick = { controller?.seekToPreviousMediaItem() }, modifier = Modifier.size(58.dp)) {
                Icon(Icons.Default.SkipPrevious, "Previous", tint = SoftWhite, modifier = Modifier.size(35.dp))
            }
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(SoftWhite).clickable {
                    if (playing) controller?.pause() else controller?.play()
                },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    if (playing) "Pause" else "Play", tint = Ink, modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = { controller?.seekToNextMediaItem() }, modifier = Modifier.size(58.dp)) {
                Icon(Icons.Default.SkipNext, "Next", tint = SoftWhite, modifier = Modifier.size(35.dp))
            }
            IconButton(onClick = {
                controller?.repeatMode = when (controller?.repeatMode) {
                    androidx.media3.common.Player.REPEAT_MODE_OFF -> androidx.media3.common.Player.REPEAT_MODE_ALL
                    androidx.media3.common.Player.REPEAT_MODE_ALL -> androidx.media3.common.Player.REPEAT_MODE_ONE
                    else -> androidx.media3.common.Player.REPEAT_MODE_OFF
                }
            }) {
                Icon(Icons.Default.Repeat, "Repeat", tint = if ((controller?.repeatMode ?: 0) != 0) SoftWhite else Muted)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("HINA PLAYZ  •  LISTEN BEYOND", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun BottomBar(selectedTab: Int, onHome: () -> Unit, onFavorites: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        NavigationItem(Icons.Default.LibraryMusic, "LIBRARY", selectedTab == 0, onHome)
        NavigationItem(Icons.Default.FavoriteBorder, "FAVORITES", selectedTab == 1, onFavorites)
    }
}

@Composable
private fun NavigationItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 25.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (selected) SoftWhite else Muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (selected) SoftWhite else Muted, fontSize = 8.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String, message: String, action: String, onAction: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().fillMaxHeight().padding(horizontal = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(Panel), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = SoftWhite, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(22.dp))
        Text(title, color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(containerColor = SoftWhite, contentColor = Ink),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(action, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
    }
}
