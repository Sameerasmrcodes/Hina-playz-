# HINA PLAYZ — Android source

Native Android offline music-player starter built with Kotlin, Jetpack Compose and AndroidX Media3.

## Current implementation
- MediaStore local-audio discovery with runtime permission handling
- Local search and a two-filter library view (All songs / Favorites)
- Media3 playback queue, play/pause, previous/next, seek, shuffle and repeat
- MediaSessionService for background media-session integration
- Minimal dark interface and mini-player / Now Playing views

## Not yet implemented
The supplied PRD is larger than the current starter project. In particular, the four-section navigation, persistent favorites/playlists/history, full Light/Dark/System themes, embedded album-art loading, functional equalizer, sleep timer and full QA pass remain outstanding. The current UI should not be represented as complete against the PRD.

## Build a debug APK

### Android Studio
1. Open this `HinaPlayzAndroid` directory in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The output is `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions
A workflow is included at `.github/workflows/android.yml`. Push this project to a GitHub repository, then open **Actions → Android APK → Run workflow**. It builds the debug APK and publishes it as the `hina-playz-debug-apk` artifact.

## Technical notes
- Application ID: `com.hinaplayz.app`
- Minimum SDK: 23
- Compile / target SDK: 35
- JDK: 17
- Gradle: 8.9
- AndroidX Media3: 1.5.1

This workspace does not contain an Android SDK or Gradle installation, so an APK could not be compiled or device-tested here. Do not treat a source ZIP as an APK or as proof of a successful build.
